// API الكامل - النسخة 2. الصقه مكان Code.gs ثم Deploy > Manage deployments > Edit > New version
const SH = { ENG: 'هندسة', LOG: 'هندسة مراجعه', MEAS: 'القياسات', PH: 'الصور', HOT: 'محولات محملة', SYNC: 'مزامنة', USR: 'المستخدمون' };
const LOCKED = ['رقم داخلي', 'آخر تعديل بواسطة', 'وقت آخر تعديل'];
const HOTH = ['الرقم الداخلي', 'مصدر التغذية', 'المغذي', 'اسم المحول', 'عام/خاص', 'نوع المحول', 'التركيب', 'الجهد ك.ف', 'السعة ك ف أ', 'حمل N', 'حمل العمومي T', 'حمل العمومي S', 'حمل العمومي R', 'نسبة التحميل %', 'تاريخ الرصد'];
const NEWCOLS = ['قرية / كفر', 'سنة صنع المحول', 'حمل N', 'نسبة التحميل %', 'حالة الاتزان', 'جهد المحول الثانوي', 'سعة القاطع العمومي (أمبير)', 'بُعد مسافة المحول عن مصدر التغذية (كم)', 'نموذج حرارة المتوسط', 'نموذج حرارة المنخفض', 'كود لوحة المنخفض', 'كود لوحة المتوسط', 'آخر تعديل بواسطة', 'وقت آخر تعديل'];
const OPS = { // نوع العملية: [الصفحة, الأعمدة, القيم]
  ans: ['الفحص السنوي', ['وقت', 'الزيارة', 'رقم المحول', 'السؤال', 'الإجابة', 'ملاحظة', 'الفني'], o => [o.visit, o.id, o.q, o.a, o.note || '']],
  th: ['قراءات الحرارة', ['وقت', 'الزيارة', 'رقم المحول', 'النموذج', 'القسم', 'الصف', 'R', 'S', 'T', 'حرارة الجو', 'نقطة ساخنة', 'إجراء المعالجة', 'الفني', 'قيمة بعد المعالجة'], o => [o.visit, o.id, o.m, o.sec, o.row, o.R, o.S, o.T, o.amb, o.hot ? 'نعم' : 'لا', o.act || '', 'NAME', o.after || '']],
  maint: ['الصيانات', ['وقت', 'الزيارة', 'رقم المحول', 'البند', 'ما تم', 'ملاحظة/توصية', 'الفني'], o => [o.visit, o.id, o.key, o.done || '', o.note || '']],
  visit: ['الزيارات', ['وقت', 'الزيارة', 'رقم المحول', 'الحالة', 'الفني'], o => [o.visit, o.id, o.st]],
  alert: ['تنبيهات', ['وقت', 'رقم المحول', 'النوع', 'القيمة المسجلة', 'الفني', 'الحالة'], o => [o.id, o.f, o.reg, 'NAME', 'جديد']]
};
const ss_ = () => SpreadsheetApp.getActive();
const sh_ = (n, head) => { let s = ss_().getSheetByName(n); if (!s) { s = ss_().insertSheet(n); if (head) s.appendRow(head); } return s; };
const out_ = o => ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
const all_ = n => sh_(n).getDataRange().getValues();
function auth_(pin) { const v = all_(SH.USR); for (let i = 1; i < v.length; i++) if (String(v[i][0]).trim() === String(pin).trim() && String(v[i][3]).trim() === 'نعم') return { name: v[i][1], role: v[i][2] }; return null; }
function schema_() {
  const s = sh_(SH.ENG), h = s.getRange(1, 1, 1, s.getLastColumn()).getValues()[0];
  const ren = { 'قرية / مدينة': 'قرية / كفر', 'حمل T': 'حمل العمومي T', 'حمل S': 'حمل العمومي S', 'حمل R': 'حمل العمومي R' };
  h.forEach((x, i) => { if (ren[x]) { s.getRange(1, i + 1).setValue(ren[x]); h[i] = ren[x]; } });
  NEWCOLS.forEach(n => { if (h.indexOf(n) < 0) { h.push(n); s.getRange(1, h.length).setValue(n); } });
  if (!ss_().getSheetByName('المغذيات')) {
    const v = s.getDataRange().getValues(), fi = h.indexOf('المغذي'), si = h.indexOf('مصدر التغذية'), seen = {}, rows = [];
    v.slice(1).forEach(r => { if (r[fi] && !seen[r[fi]]) { seen[r[fi]] = 1; rows.push([r[fi], r[si] || '']); } });
    const f = sh_('المغذيات', ['اسم المغذي', 'مصدر التغذية']); if (rows.length) f.getRange(2, 1, rows.length, 2).setValues(rows);
  }
}
function doGet() { return out_({ ok: true }); }
function doPost(e) {
  try {
    const r = JSON.parse(e.postData.contents), u = auth_(r.pin);
    if (!u) return out_({ ok: false, err: 'pin' });
    if (r.a === 'login') return out_({ ok: true, user: u });
    if (r.a === 'boot') {
      schema_();
      const v = all_(SH.ENG), cfg = {}; all_('الإعدادات').slice(1).forEach(x => cfg[x[0]] = x[1]);
      const L = all_('قوائم'), lists = {}; L[0].forEach((h, i) => lists[h] = L.slice(1).map(x => x[i]).filter(x => x !== ''));
      const thumbs = {}; all_('صور مصغرة').slice(1).forEach(x => { if (x[0]) thumbs[x[0]] = x[1]; });
      const yr = new Date().getFullYear();
      return out_({ ok: true, h: v[0], rows: v.slice(1).filter(x => x[0]), q: all_('الأسئلة').slice(1), th: all_('نماذج الحرارة').slice(1), cfg, lists, thumbs,
        feeders: all_('المغذيات').slice(1).filter(x => x[0]), srt: all_('السورتيهات').slice(1).filter(x => x[0]),
        done: [...new Set(all_('الزيارات').slice(1).filter(x => x[3] === 'مغلقة' && new Date(x[0]).getFullYear() === yr).map(x => x[2]))] });
    }
    if (r.a === 'sync') return out_(sync_(r.ops, u));
    if (r.a === 'photo') return out_(photo_(r, u));
    if (u.role !== 'إدارة') return out_({ ok: false, err: 'role' });
    if (r.a === 'sheet') { const v = all_(r.n); return out_({ ok: true, h: v[0], rows: v.slice(1).slice(-80) }); }
    if (r.a === 'hist') { const f = n => all_(n).filter((x, i) => i > 0 && (x[1] === r.id || x[2] === r.id)); return out_({ ok: true, ph: f('الصور'), maint: f('الصيانات'), meas: f('القياسات'), th: f('قراءات الحرارة') }); }
    if (r.a === 'xlsx') { const res = UrlFetchApp.fetch('https://docs.google.com/spreadsheets/d/' + ss_().getId() + '/export?format=xlsx', { headers: { Authorization: 'Bearer ' + ScriptApp.getOAuthToken() } }); return out_({ ok: true, b64: Utilities.base64Encode(res.getContent()) }); }
    if (r.a === 'img') return out_({ ok: true, b64: Utilities.base64Encode(DriveApp.getFileById(r.fid).getBlob().getBytes()) });
    if (r.a === 'reopen') { sh_('الزيارات').appendRow([new Date(), r.visit || '', r.id, 'أُعيد فتحها', u.name]); return out_({ ok: true }); }
    return out_({ ok: false, err: 'a' });
  } catch (x) { return out_({ ok: false, err: String(x) }); }
}
function sync_(ops, u) {
  const L = LockService.getScriptLock(); L.waitLock(30000);
  try {
    const sy = sh_(SH.SYNC, ['uid']), seen = new Set(sy.getDataRange().getValues().map(x => x[0])), done = [];
    const eng = sh_(SH.ENG), v = eng.getDataRange().getValues(), h = v[0];
    const col = n => { let i = h.indexOf(n); if (i < 0) { h.push(n); i = h.length - 1; eng.getRange(1, i + 1).setValue(n); } return i; };
    const g = (r, n) => { const i = h.indexOf(n); return i < 0 || v[r][i] === undefined ? '' : v[r][i]; };
    ops.forEach(o => {
      if (seen.has(o.uid)) { done.push(o.uid); return; }
      const r = v.findIndex((x, i) => i > 0 && x[0] === o.id), now = new Date();
      try {
        if (OPS[o.t]) { const d = OPS[o.t], vals = d[2](o).map(x => x === 'NAME' ? u.name : x); sh_(d[0], d[1]).appendRow([now, ...vals, ...(d[1].slice(-1)[0] === 'الفني' && vals.indexOf(u.name) < 0 ? [u.name] : [])]); }
        else if (o.t === 'addfeeder') sh_('المغذيات', ['اسم المغذي', 'مصدر التغذية']).appendRow([o.name, o.src || '']);
        else if (o.t === 'thumb') { const t = sh_('صور مصغرة', ['رقم المحول', 'بيانات']), d = t.getDataRange().getValues(), i = d.findIndex((x, k) => k > 0 && x[0] === o.id); if (i > 0) t.getRange(i + 1, 2).setValue(o.b64); else t.appendRow([o.id, o.b64]); }
        else if (o.t === 'addtr' && r < 0) { const row = h.map(n => o.row[n] === undefined ? '' : o.row[n]); eng.appendRow(row); v.push(row); }
        else if (o.t === 'edit' && r > 0 && LOCKED.indexOf(o.f) < 0) {
          const c = col(o.f), old = g(r, o.f) === '' ? '' : String(g(r, o.f));
          eng.getRange(r + 1, c + 1).setValue(o.v); v[r][c] = o.v;
          eng.getRange(r + 1, col('آخر تعديل بواسطة') + 1).setValue(u.name); eng.getRange(r + 1, col('وقت آخر تعديل') + 1).setValue(now);
          sh_(SH.LOG, ['وقت التعديل', 'رقم المحول', 'المغذي', 'اسم المحول', 'الخانة', 'القيمة قبل', 'القيمة بعد', 'من عدّل', 'مصدر التعديل', 'النتيجة'])
            .appendRow([now, o.id, g(r, 'المغذي'), g(r, 'اسم المحول'), o.f, old, o.v, u.name, o.src || 'تعديل مباشر', old === '' ? 'جديد' : 'معدّل']);
        }
        else if (o.t === 'caps') { const s = sh_('المكثفات', ['رقم المحول', 'رقم المكثف', 'قدرته KVAR', 'سعة قاطع المكثفات (A)']); const d = s.getDataRange().getValues(); for (let i = d.length - 1; i > 0; i--) if (d[i][0] === o.id) s.deleteRow(i + 1); (o.caps || []).forEach((c, k) => s.appendRow([o.id, k + 1, c, o.brk || ''])); }
        else if (o.t === 'loads' && r > 0) loads_(o, r, h, col, eng, u, now, g, v);
      } catch (x) { sh_('أخطاء', ['وقت', 'العملية', 'الخطأ']).appendRow([now, o.t, String(x)]); }
      sy.appendRow([o.uid]); done.push(o.uid);
    });
    return { ok: true, done };
  } finally { L.releaseLock(); }
}
function stats_(R, S, T, cap) {
  const a = (R + S + T) / 3, N = Math.max(R, S, T) - a;
  return { N: Math.round(N * 10) / 10, L: cap ? Math.round(a / (cap * 1.44) * 100) : '', st: a && Math.max(Math.abs(R - a), Math.abs(S - a), Math.abs(T - a)) / a > 0.05 ? 'غير متزن' : 'متزن' };
}
function loads_(o, r, h, col, eng, u, now, g, v) {
  const cap = Number(g(r, 'السعة ك ف أ')) || 0, k = stats_(o.R, o.S, o.T, cap), M = sh_(SH.MEAS, ['وقت', 'رقم المحول', 'المرحلة', 'الجزء', 'قاطع عمومي', 'سعة القاطع (A)', 'R', 'S', 'T', 'N المقيس', 'N بالمعادلة', 'نسبة التحميل %', 'الحالة', 'الفني', 'جهد R', 'جهد S', 'جهد T', 'الربع']);
  M.appendRow([now, o.id, o.ph, 'العمومي', o.brk ? 'نعم' : 'لا', o.cap || '', o.R, o.S, o.T, o.nm === '' || o.nm === undefined ? '' : o.nm, k.N, k.L, k.st, u.name, o.vr || '', o.vs || '', o.vt || '', o.qm || '']);
  (o.srt || []).forEach(s => { const q = stats_(s.R || 0, s.S || 0, s.T || 0, 0); M.appendRow([now, o.id, o.ph, 'سورتيه ' + s.n + ' ' + (s.name || ''), '', s.A || '', s.R, s.S, s.T, s.N === undefined ? '' : s.N, q.N, '', q.st, u.name, s.vr || '', s.vs || '', s.vt || '', o.qm || '']); });
  if (o.ph === 'before' && (o.srt || []).length) {
    const S = sh_('السورتيهات', ['رقم المحول', 'رقم السورتيه', 'اسم السورتيه', 'مقاس كابل البداية', 'طول كابل البداية (م)', 'مقاس الهوائي', 'طول الهوائي (م)', 'سعة قاطع السورتيه (A)', 'حمل R', 'حمل S', 'حمل T', 'حمل N', 'جهد R', 'جهد S', 'جهد T', 'نسبة الاتزان', 'وقت التحديث']), d = S.getDataRange().getValues();
    o.srt.forEach(s => { const q = stats_(s.R || 0, s.S || 0, s.T || 0, 0), rec = [o.id, s.n, s.name || '', s.cbS || '', s.cbL || '', s.ovS || '', s.ovL || '', s.A || '', s.R, s.S, s.T, s.N === undefined ? '' : s.N, s.vr || '', s.vs || '', s.vt || '', q.st, now], i = d.findIndex((x, j) => j > 0 && x[0] === o.id && +x[1] === +s.n); if (i > 0) S.getRange(i + 1, 1, 1, rec.length).setValues([rec]); else S.appendRow(rec); });
  }
  const set = (sheet, hh, row, c) => { [['حمل العمومي R', o.R], ['حمل العمومي S', o.S], ['حمل العمومي T', o.T], ['حمل N', k.N], ['نسبة التحميل %', k.L], ['حالة الاتزان', k.st], ['سعة القاطع العمومي (أمبير)', o.brk ? o.cap : '']].forEach(p => { const i = hh.indexOf(p[0]); if (i >= 0 && p[1] !== undefined) sheet.getRange(row, i + 1).setValue(p[1]); }); };
  if (o.qm) {
    const name = 'هندسة ' + o.qm, qs = ss_().getSheetByName(name) || (() => { const s = ss_().insertSheet(name); s.getRange(1, 1, 1, h.length).setValues([h]); s.getRange(1, h.length + 1, 1, 2).setValues([['الفني', 'تاريخ الزيارة']]); return s; })();
    const qd = qs.getDataRange().getValues(), qh = qd[0]; let i = qd.findIndex((x, j) => j > 0 && x[0] === o.id);
    if (i < 0) { qs.appendRow(v[r].concat(Array(Math.max(0, qh.length - v[r].length)).fill(''))); i = qs.getLastRow() - 1; }
    set(qs, qh, i + 1); const fi = qh.indexOf('الفني'), ti = qh.indexOf('تاريخ الزيارة'); if (fi >= 0) qs.getRange(i + 1, fi + 1).setValue(u.name); if (ti >= 0) qs.getRange(i + 1, ti + 1).setValue(now);
  }
  if (o.ph !== 'before') return;
  set(eng, h, r + 1); [['حمل العمومي R', o.R], ['حمل العمومي S', o.S], ['حمل العمومي T', o.T]].forEach(p => col(p[0]));
  const hs = sh_(SH.HOT, HOTH), d = hs.getDataRange().getValues(), i = d.findIndex((x, j) => j > 0 && x[0] === o.id);
  if (!(k.L > 80)) { if (i > 0) hs.deleteRow(i + 1); return; }
  const rec = [o.id, g(r, 'مصدر التغذية'), g(r, 'المغذي'), g(r, 'اسم المحول'), g(r, 'عام/خاص'), g(r, 'نوع المحول'), g(r, 'التركيب'), g(r, 'الجهد ك.ف'), g(r, 'السعة ك ف أ'), k.N, o.T, o.S, o.R, k.L, now];
  if (i > 0) hs.getRange(i + 1, 1, 1, rec.length).setValues([rec]); else hs.appendRow(rec);
}
function photo_(r, u) {
  const sy = sh_(SH.SYNC, ['uid']); if (sy.getDataRange().getValues().some(x => x[0] === r.uid)) return { ok: true };
  const it = DriveApp.getFoldersByName('صور_الصيانة'), f = it.hasNext() ? it.next() : DriveApp.createFolder('صور_الصيانة');
  const file = f.createFile(Utilities.newBlob(Utilities.base64Decode(r.b64), 'image/jpeg', r.id + '_' + String(r.kind).replace(/[^\w\u0600-\u06FF]/g, '_') + '_' + Date.now() + '.jpg'));
  sh_(SH.PH, ['وقت', 'رقم المحول', 'الزيارة', 'نوع الصورة', 'الرابط', 'من رفع', 'معرّف الملف']).appendRow([new Date(), r.id, r.visit || '', r.kind, file.getUrl(), u.name, file.getId()]);
  sy.appendRow([r.uid]); return { ok: true, url: file.getUrl() };
}
